# Logo Placeholder

Please place your circular logo file "circular logog trihari.png" in this public directory.

The component is already configured to use this logo at the path:
- `/circular logog trihari.png`

Make sure your logo file has a transparent background for best results with the dark/light theme toggle.
