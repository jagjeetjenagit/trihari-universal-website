// Backup file created before cleaning up audition section
