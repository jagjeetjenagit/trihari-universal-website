import React from 'react'

export default function TestComponent() {
  return (
    <div className="min-h-screen bg-red-500 flex items-center justify-center">
      <h1 className="text-white text-4xl font-bold">TEST - React is working!</h1>
    </div>
  )
}
